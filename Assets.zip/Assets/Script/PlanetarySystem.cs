using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 储存行星系的数据，并提供文明在行星系的行为
/// </summary>
public class PlanetarySystem : MonoBehaviour
{
    public List<Planet> planets;
    public FixedStar fixedStar;

    public CivilizationSO civilization;

    public int civilizationResource; //文明在该行星用有的资源
    [SerializeField]private int remainResource;

    float timeInterval = 0;

    // Update is called once per frame
    void Update()
    {
        if (timeInterval >= 1.0)//每一秒钟执行一次
        {
            civilizationResourceIncrease();
            civilizationScienceProgressIncrease();

            timeInterval = 0;
        }
        timeInterval += Time.deltaTime;
    }

    /// <summary>
    /// 如果行星系存在文明，则增加文明的科技研发进度
    /// </summary>
    private void civilizationScienceProgressIncrease()
    {
        if (existCivilization() != false)
            civilization.addScienceProgress(civilization.scienceDevelopmentSpeed);
    }

    /// <summary>
    /// 如果行星系是存在文明，则增加文明的资源
    /// </summary>
    private void civilizationResourceIncrease()
    {
        if (existResource() != false)
        {
            if (existCivilization() != false)
                addResource(civilization.miningSpeed);
        }
        
    }

    /// <summary>
    /// 根据文明的每秒获得的资源，为文明增加资源和减少行星系剩余资源
    /// </summary>
    /// <param name="miningSpeed">文明一秒钟获得的资源</param>
    private void addResource(int miningSpeed)
    {
        civilizationResource += miningSpeed;
        remainResource -= miningSpeed;
    }

    /// <summary>
    /// 判断该行星是否存在文明
    /// </summary>
    /// <returns>文明是否存在</returns>
    public bool existCivilization()
    {
        if (civilization != null)
            return true;
        return false;
    }

    /// <summary>
    /// 判断行星系是否存在剩余资源
    /// </summary>
    /// <returns></returns>
    public bool existResource()
    {
        if (remainResource <= 0)
            return false;
        return true;
    }

    
}
