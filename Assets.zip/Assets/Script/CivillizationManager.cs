using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 对
/// </summary>
public class CivillizationManager : MonoBehaviour
{
    public List<CivilizationSO> civilizations;

    // Update is called once per frame
    void Update()
    {
        scienceLevelUP(civilizations[0]);
    }

    private void scienceLevelUP(CivilizationSO civilization)
    {
        if (reachTechnologicalSingularity(civilization) == true)
        {
            civilization.scienceLevel += 1;
            civilization.setScienceProgress(0);
        }
            
    }

    /// <summary>
    /// 检查文明对科技进度是否达到科技大爆炸点
    /// </summary>
    /// <param name="civilization">文明</param>
    /// <returns>如果到达 true，否则 false</returns>
    private bool reachTechnologicalSingularity(CivilizationSO civilization)
    {
        if (civilization.getScienceProgress() >= civilization.getTechnologicalSingularity())
            return true;
        return false;
    }
}
