using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 初始化行星系的脚本，负责创造行星和恒星
/// </summary>
public class PlanetarySystemInitialization : MonoBehaviour
{
    public PlanetarySystem planetarySystem;
    public int planetNum;

    public PlanetsFactorySO planetsFactory;
    public FixedStarFactorySO fixedStarFactory;

    public List<PlanetTypeSO> planetType; //气态行星或类地行星
    public List<PlanetElementSO> planetElements;
    public List<PlanetTagSO> planetTags;

    private void Start()
    {
        creatFixedStar();
        for (int i = 0; i <= planetNum-1; i++)
        {
            creatPlanets();
        }
        
    }

    /// <summary>
    /// 通过PlanetsFactorySo提供的方式创造行星，并将行星系设置为行星parent
    /// </summary>
    private void creatPlanets()
    {
        float distance = Random.Range(6, 10);
        Planet planet = planetsFactory.createPlanet(planetType[0],planetarySystem.fixedStar.transform.position,distance);
        planet.transform.parent = transform;
        planetarySystem.planets.Add(planet);
    }

    /// <summary>
    /// 通过FixedStarFactorySo提供的方式创造行星，并将行星系设置为恒星parent
    /// </summary>
    private void creatFixedStar()
    {
        FixedStar fixedStar = fixedStarFactory.createFixedStar();
        fixedStar.transform.parent = transform;
        fixedStar.transform.position = transform.position;
        planetarySystem.fixedStar = fixedStar;
    }

}
