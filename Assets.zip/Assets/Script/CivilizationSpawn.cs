using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 对文明的数据进行初始化
/// </summary>
public class CivilizationSpawn : MonoBehaviour
{
    public List<CivilizationSO> civilizations;
    public List<PlanetarySystem> planetarySystems;

    
    void Start()
    {
        main();
    }

    /// <summary>
    /// 重置和初始化文明的所有 attribute
    /// </summary>
    private void main()
    {
        for (int i = 0; i < civilizations.Count; i++)
        {
            resetPlanetarySystem(civilizations[i]);
            resetScienceProgress(civilizations[i]);
            initalPlanetarySystem(civilizations[i]);
            initializationScienceLeve(civilizations[i]);
        }
    }

    /// <summary>
    /// 重置文明拥有的行星系
    /// </summary>
    /// <param name="civilization">文明</param>
    private void resetPlanetarySystem(CivilizationSO civilization)
    {
        civilization.planetarySystems.Clear();
    }

    /// <summary>
    /// 重置文明的科技研发进度
    /// </summary>
    /// <param name="civilization"></param>
    private void resetScienceProgress(CivilizationSO civilization)
    {
        civilization.setScienceProgress(0);
    }

    /// <summary>
    /// 初始化该文明的文明特性
    /// </summary>
    /// <param name="civilization">文明</param>
    private void initializationCharacteristic(CivilizationSO civilization)
    {
        
    }

    /// <summary>
    /// 初始化文明的科学等级
    /// </summary>
    /// <param name="civilization">文明</param>
    private void initializationScienceLeve(CivilizationSO civilization)
    {
        
        if (civilization.getPlayControl() == true)
            civilization.scienceLevel = 1;
    }

    /// <summary>
    /// 为文明选择初始的行星系
    /// </summary>
    /// <remarks>当前阶段暂时为随机挑选一个行星系并加入文明</remarks>
    /// <param name="civilization"></param>
    private void initalPlanetarySystem(CivilizationSO civilization)
    {
        int num = Random.Range(0, planetarySystems.Count);
        planetarySystems[num].civilization = civilization;
        civilization.planetarySystems.Add(planetarySystems[num]);
    }

    
}
