using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PlanetarySystemFactory", menuName = "TechnologyTree/SpacecraftTechnology")]
public class SpacecraftTechnologySO : TechnologyTreeSO
{
    
}
