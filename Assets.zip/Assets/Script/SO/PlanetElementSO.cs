using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 决定星球外观的标签
/// </summary>
[CreateAssetMenu(fileName = "PlanetsElement", menuName = "Planets/PlanetsElement")]
public class PlanetElementSO : ScriptableObject
{
    public string name;
}
