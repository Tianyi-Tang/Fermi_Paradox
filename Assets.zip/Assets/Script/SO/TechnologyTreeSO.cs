using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 科技树中所有技能的父类
/// </summary>
[CreateAssetMenu(fileName ="TechnologyTree", menuName ="TechnologyTree/TechnologyPoint")]
public class TechnologyTreeSO : ScriptableObject
{
    [SerializeField]private string name;
    [SerializeField]private TechnologyTreeSO per_TechnonlogyPoint;
    [SerializeField]private TechnologyTreeSO post_TechnologyPoint;

    public bool active;

    public string getName()
    {
        return name;
    }

    public TechnologyTreeSO getPer_TechnologyPoint()
    {
        return per_TechnonlogyPoint;
    }

    public TechnologyTreeSO getPost_TechnologyPoint()
    {
        return post_TechnologyPoint;
    }

    

    

    
}
