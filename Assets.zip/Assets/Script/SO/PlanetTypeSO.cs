using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 储存行星是类型行星或气态行星
/// </summary>
[CreateAssetMenu(fileName = "PlanetType", menuName ="Planets/PlanetType")]
public class PlanetTypeSO : ScriptableObject
{
    public string name;
}
