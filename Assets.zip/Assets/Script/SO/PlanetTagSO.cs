using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 决定星球属性的标签
/// </summary>
[CreateAssetMenu(fileName = "PlanetTag", menuName = "Planets/PlanetTag")]
public class PlanetTagSO : ScriptableObject
{
    public string name;
}