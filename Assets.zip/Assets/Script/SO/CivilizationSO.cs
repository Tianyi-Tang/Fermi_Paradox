using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Civilization", menuName = "Civilization")]
public class CivilizationSO : ScriptableObject
{
    public string name;
    [SerializeField]private bool playControl; //该文明是否由玩家控制

    public int scienceLevel;
    [SerializeField]private int scienceProgress; //科技研发进度
    [SerializeField]private int technologicalSingularity; //科技大爆炸
    public int scienceDevelopmentSpeed; //文明每秒钟科技发展的速度

    public List<PlanetarySystem> planetarySystems;
    public int miningSpeed; //每秒钟文明从一个行星系收获的资源

    public bool getPlayControl()
    {
        return playControl;
    }

    public void setScienceProgress(int newScienceProgress)
    {
        scienceProgress = newScienceProgress;
    }

    public int getScienceProgress()
    {
        return scienceProgress;
    }

    /// <summary>
    /// 更新文明当前的科技研发进度
    /// </summary>
    /// <param name="increaseProgress">当前增加的科技研发进度</param>
    public void addScienceProgress(int increaseProgress)
    {
        scienceProgress = scienceProgress + increaseProgress;
    }

    public void setTechnologicalSingularity(int newTechnologicalSingularity)
    {
        technologicalSingularity = newTechnologicalSingularity;
    }

    public int getTechnologicalSingularity()
    {
        return technologicalSingularity;
    }


}
