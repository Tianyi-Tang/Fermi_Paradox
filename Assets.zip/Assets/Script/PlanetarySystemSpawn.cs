using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 生成行星系并设置位置
/// </summary>
public class PlanetarySystemSpawn : MonoBehaviour
{
    public PlanetarySystemFactorySO planetarySystemFactory;
    public List<Vector3> planetarySystemList;
    [SerializeField]private float minDistanceDifference;//两个行星系最小相距的距离
    [SerializeField] private int planetarySystemNum;

    [SerializeField]private CivilizationSpawn civilizationSpawn;




    void Start()
    {
        Vector3 planetarySystemPos = new Vector3(0,0,0);
        planetarySystemList = new List<Vector3>();
        for (int i = 0; i <= planetarySystemNum; i++)
        {
            createPlanetarySystem(ensurePosition(planetarySystemList,planetarySystemPos));
        }
        planetarySystemList.Add(planetarySystemPos);
        
        
    }

    /// <summary>
    /// 通过PlanetarySystemFactorySO提供的方式生成行星系,并将行星系添加到 civilizationSpawn
    /// </summary>
    public void createPlanetarySystem(Vector3 planetarySystemPos)
    {
        int planetNum = Random.Range(1,4);
        PlanetarySystemInitialization planetarySystem = planetarySystemFactory.createPlanetarySystem(planetNum, planetarySystemPos);
        civilizationSpawn.planetarySystems.Add(planetarySystem.GetComponent<PlanetarySystem>());
    }

    /// <summary>
    /// 检查新生成的行星系的位置是否与其他行星系太过靠近
    /// </summary>
    /// <param name="planetarySystemList">储存所有行星系的list</param>
    /// <param name="planetarySystemPos">生成行星系的位置</param>
    /// <returns>两个行星系是否过于靠近</returns>
    public bool chekcDistance(List<Vector3> planetarySystemList, Vector3 planetarySystemPos)
    {
        for (int i = 0; i <= planetarySystemList.Count; i++)
        {
            if (Vector3.Distance(planetarySystemList[i], planetarySystemPos) < minDistanceDifference)
                return false;
            return true;

        }
        return true;
        
    }

    /// <summary>
    /// 确定新生成的行星系的位置
    /// </summary>
    /// <param name="planetarySystemList">储存所有行星系的list</param>
    /// <param name="planetarySystemPos">用于存储行星系位置的空变量</param>
    /// <returns>行星系的位置</returns>
    private Vector3 ensurePosition(List<Vector3> planetarySystemList, Vector3 planetarySystemPos)
    {
        while (true)
        {
            planetarySystemPos.Set(Random.Range(50, -50), Random.Range(10, -10), Random.Range(50, -50));
            if (planetarySystemList.Count != 0)
            {
                if (chekcDistance(planetarySystemList, planetarySystemPos) != false)
                    planetarySystemList.Add(planetarySystemPos);
                return planetarySystemPos;
            }
            else
            {
                planetarySystemList.Add(planetarySystemPos);
                return planetarySystemPos;
            }
                

        }
        
    }

}
