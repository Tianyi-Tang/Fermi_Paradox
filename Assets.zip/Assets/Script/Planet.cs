using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 储存行星的数据；控制行星的自转，公转和显示轨道
/// </summary>
/// <remarks>Andy 25/08/21</remarks>
public class Planet : MonoBehaviour
{
    public float mass;
    public float radius; // 1 million km(real) = 1m(unity)
    public float revolutionSpeed;
    public float rotationSpeed;
    public Vector3 fixedStarPosition;
    public float distanceBetweenFixedStar; // 1 million km(real) = 1m(unity)

    public PlanetTypeSO planetType;
    public List<PlanetElementSO> planetElements; //决定星球外观的数据
    public List<PlanetTagSO> planetTag;

    public int resource;

    private void Start()
    {
        changePosition();
        orbit();
    }

    void Update()
    {
        revolution();
        rotation();
    }

    /// <summary>
    /// 实现行星的公转
    /// </summary>
    private void revolution()
    {
        transform.RotateAround(fixedStarPosition, Vector3.up, Time.deltaTime * revolutionSpeed);
    }

    /// <summary>
    /// 实现星球的自转
    /// </summary>
    private void rotation()
    {
        transform.Rotate(Vector3.up, Time.deltaTime * rotationSpeed);
    }

    /// <summary>
    /// 展现星球的运行轨道
    /// </summary>
    private void orbit()
    {
        var gol = new GameObject { name = "Circle" };
        gol.transform.position = fixedStarPosition;
        gol.DrawCircle(distanceBetweenFixedStar, 0.2f);
    }

    /// <summary>
    /// 根据恒星的位置和与恒星的距离来改变星球的位置
    /// </summary>
    private void changePosition()
    {
        transform.Translate(fixedStarPosition.x, fixedStarPosition.y, fixedStarPosition.z + distanceBetweenFixedStar);
    }
}
