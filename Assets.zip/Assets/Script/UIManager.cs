using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 根据鼠标的点击，显示相应的UI
/// </summary>
public class UIManager : MonoBehaviour
{
    private Vector3 screenPoint; //点击的物体在屏幕坐标系的位置
    [SerializeField] private Vector3 cameraPosition; // 当鼠标点击物体时，相机当位置
    

    public GameObject planetarySystemOverViewUI;//行星系简介UI
    [SerializeField]private float x_rayDistance; //点击行星系和行星系简介UI在 x坐标的距离
    [SerializeField]private float y_rayDistance; //点击行星系和行星系简介UI在 y坐标的距离
    [SerializeField]private float cameraMarginOfError;

    // Update is called once per frame
    void Update()
    {
        planetarySystemUIActive();
    }

    /// <summary>
    /// 当点击的目标为行星系时候，根据行星的位置，显示行星系简介UI（planetarySystemOverViewUI）
    /// </summary>
    private void planetarySystemUIActive()
    {
        if (Input.GetMouseButtonDown(0) == true)
        {
            if (GameObjectEx.selectObject() == null)
            {
                planetarySystemOverViewUI.SetActive(false);
            }
            else if (GameObjectEx.selectObject().name.CompareTo("Planetary system(Clone)") == 0)
            {

                changePosition(GameObjectEx.selectObject());
                planetarySystemOverViewUI.SetActive(true);
                cameraPosition = Camera.main.transform.position;
            }

        }
        
    }

    /// <summary>
    /// 根据点击行星系的位置和与UI的距离，改变UI
    /// </summary>
    /// <param name="clickObject">点击行星系的位置</param>
    private void changePosition(Transform clickObject)
    {
        screenPoint = Camera.main.WorldToScreenPoint(clickObject.position);
        screenPoint.Set(screenPoint.x + x_rayDistance, screenPoint.y + y_rayDistance, 0);
        planetarySystemOverViewUI.transform.position = screenPoint;
    }


    private void cameraMoving()
    {
        Debug.Log(Vector3.Distance(Camera.main.transform.position, cameraPosition)); //bug，两个位置误差太打
    }
    
}
