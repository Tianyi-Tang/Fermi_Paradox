using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 控制摄像机的移动和放大；
/// </summary>
public class CameraController : MonoBehaviour
{
    [SerializeField] private float panSpeed;
    [SerializeField] private float moveTime; //缓冲速度，用于Vector3.Lerp
    private Vector3 newPos;

    private Transform cameraTrans; //子物体，mianCamera
    [SerializeField] private Vector3 zoomAmount; //通过改变zoomAmount的X和Y，实现相机缩放
    private Vector3 newZoom;

    

    private void Start()
    {
        newPos = transform.position;

        cameraTrans = transform.GetChild(0);
        newZoom = cameraTrans.localPosition;

    }

    void Update()
    {
        HandleMovementInput();
    }

    private void HandleMovementInput()
    {
        //实现相机的左右移动
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            newPos += transform.forward * panSpeed * Time.deltaTime;
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            newPos -= transform.forward * panSpeed * Time.deltaTime;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            newPos += transform.right * panSpeed * Time.deltaTime;
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            newPos -= transform.right * panSpeed * Time.deltaTime;

        //实现相机的缩放
        if (Input.GetKey(KeyCode.E)) //放大
            newZoom += zoomAmount;
        if (Input.GetKey(KeyCode.Q)) //缩小
            newZoom -= zoomAmount;

        transform.position = Vector3.Lerp(transform.position, newPos, moveTime * Time.deltaTime);

        cameraTrans.localPosition = Vector3.Lerp(cameraTrans.localPosition, newZoom, moveTime * Time.deltaTime);
    }

}
