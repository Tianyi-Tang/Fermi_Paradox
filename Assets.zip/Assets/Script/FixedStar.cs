using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 控制恒星亮度和死亡时间
/// </summary>
public class FixedStar : MonoBehaviour
{
    public float deathTimer;
    public float temperature;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
